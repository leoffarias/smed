﻿using smed_csharp.Models;
using smed_csharp.Models.Contas;
using System;
using System.Web.Mvc;

namespace smed_csharp.Controllers
{
    public class CriarContaController : Controller
    {
        Fachada fachada = Fachada.getInstance();

        private Uri RedirectUri
        {
            get
            {
                var uriBuilder = new UriBuilder(Request.Url);
                uriBuilder.Query = null;
                uriBuilder.Fragment = null;
                uriBuilder.Path = Url.Action("AutorizarFacebook");
                return uriBuilder.Uri;
            }
        }

        [AllowAnonymous]
        public ActionResult ConectarFacebook()
        {
            var result = fachada.conectarFacebook(RedirectUri);
            return Redirect(result.AbsoluteUri);
        }

        public ActionResult AutorizarFacebook(string code)
        {
            Conta usuario = fachada.autorizarFacebook(RedirectUri, code);
            
            Session["conta"] = usuario;
            
            ViewBag.Conta = usuario;
            
            return RedirectToRoute("casos_clinicos");
        }
    }
}