﻿using smed_csharp.Models;
using smed_csharp.Models.CasosClinicos;
using smed_csharp.Models.Contas;
using System.Collections.Generic;
using System.Web.Mvc;

namespace smed_csharp.Controllers
{
    public class ListarCasosClinicosController : Controller
    {
        Fachada fachada = Fachada.getInstance();

        public ActionResult ListarCasosClinicos()
        {
            if (Session["conta"] == null)
                return RedirectToAction("Index", "Home");
            else
            {
                Conta c = (Conta)Session["conta"];
                ViewBag.Conta = c;
                IEnumerable<CasoClinico> casos = fachada.listarCasosClinicos(c);
                return View(casos);
            }
        }
    }
}