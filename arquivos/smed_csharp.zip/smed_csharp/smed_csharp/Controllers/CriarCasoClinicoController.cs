﻿using smed_csharp.Models;
using smed_csharp.Models.CasosClinicos;
using smed_csharp.Models.Contas;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace smed_csharp.Controllers
{
    public class CriarCasoClinicoController : Controller
    {
        Fachada fachada = Fachada.getInstance();

        public ActionResult CriarCasoClinico()
        {
            if (Session["conta"] == null)
                return RedirectToAction("Index", "Home");
            else
            {
                return View(fachada.listarUsuarios());
            }
                
        }

        [HttpPost]
        public ActionResult CallBack(FormCollection form)
        {


            if (Session["conta"] == null)
                return RedirectToAction("Index", "Home");
            else
            {
                var a = form["titulo"];
                var b = form["descricao"];

                
                List<Conta> users = new List<Conta>();

                foreach (var conta in fachada.listarUsuarios())
                {
                    if (form[conta.email] != null && form[conta.email] != "")
                    {
                        var d = form[conta.email];
                        if (form[conta.email].Contains("true"))
                        {
                            users.Add(conta);
                        }
                    }

                    if (!users.Contains(Session["conta"]))
                    {
                        //users.Add((Conta) Session["conta"]);
                    }
                }

                CasoClinico c = new CasoClinico(a, b, users);
                fachada.criarCasoClinico(c);
                return RedirectToRoute("casos_clinicos");
            }
        }
    }
}