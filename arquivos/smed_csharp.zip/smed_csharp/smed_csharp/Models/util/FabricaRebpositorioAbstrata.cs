using smed_csharp.Models.CasosClinicos;
using smed_csharp.Models.Contas;
using smed_csharp.Models.mensagem;

namespace smed_csharp.Models.Util
{
	public interface FabricaRepositorioAbstrata
	{
	
        IRepositorioContas criarRepositorioContas();

        IRepositorioCasosClinicos criarRepositorioCasosClinicos();

        IRepositorioMensagem criarRepositorioMensagem();
	}
}