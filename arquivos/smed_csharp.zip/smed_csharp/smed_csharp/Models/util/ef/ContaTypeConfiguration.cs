﻿using smed_csharp.Models.repositorio.ef.entidadesBD;
using System.Data.Entity.ModelConfiguration;

namespace smed_csharp.Models.Util.EF
{
    public class ContaTypeConfiguration : EntityTypeConfiguration<ContaBD>
    {
        public ContaTypeConfiguration()
        {
            // Mapeando a tabela 
            this.ToTable("ContaBD");

            // Configurando a chave primária 
            this.HasKey(c => c.email);

            // Mapeando colunas 
            this.Property(c => c.id).HasColumnName("id");
            this.Property(c => c.email).HasColumnName("email");
            this.Property(c => c.nome).HasColumnName("nome");


        }
    }
}