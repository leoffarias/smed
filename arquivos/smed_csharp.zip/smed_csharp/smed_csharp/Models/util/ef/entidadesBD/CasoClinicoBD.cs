﻿using smed_csharp.Models.Contas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace smed_csharp.Models.repositorio.ef.entidadesBD
{
    public class CasoClinicoBD
    {
        public string titulo { get; internal set; }

        public string descricao { get; internal set; }

        public string participantes { get; internal set; }

        public CasoClinicoBD() {
            this.participantes = "";
        }


        public CasoClinicoBD(String titulo, String descricao,
                IEnumerable<Conta> participantes)
        {

            this.titulo = titulo;
            this.descricao = descricao;

            foreach(var p in participantes)
            {
                this.participantes += p.id + ";";
            }
            
        }

        public CasoClinicoBD(string titulo, string descricao)
        {
            this.titulo = titulo;
            this.descricao = descricao;
            this.participantes = "";
        }
    }
}