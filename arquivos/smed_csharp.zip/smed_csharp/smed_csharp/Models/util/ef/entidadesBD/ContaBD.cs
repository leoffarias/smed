﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace smed_csharp.Models.repositorio.ef.entidadesBD
{
    public class ContaBD
    {
        public string id { get; private set; }

        public string nome { get; private set; }

        public string email { get; private set; }


        public ContaBD() { }

        public ContaBD(string id, string nome, string email)
        {
            this.id = id;
            this.nome = nome;
            this.email = email;
        }
    }
}