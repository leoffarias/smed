﻿using smed_csharp.Models.Contas;
using smed_csharp.Models.mensagem;
using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Web;

namespace smed_csharp.Models.Util.EF
{
    public class MensagemTypeConfiguration : EntityTypeConfiguration<Mensagem>
    {
        public MensagemTypeConfiguration()
        {
            // Mapeando a tabela 
            this.ToTable("Mensagem");

            // Configurando a chave primária 
            this.HasKey(c => c.conteudo); //TODO: pesquisa como mapear chave composta

            // Mapeando colunas 
            this.Property(c => c.data).HasColumnName("data");
        }
    }
}