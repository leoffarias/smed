﻿using smed_csharp.Models.repositorio.ef.entidadesBD;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace smed_csharp.Models.Util.EF
{
    public class SmedContext : DbContext
    {
        
        public IDbSet<ContaBD> Contas { get; set; }
        public IDbSet<CasoClinicoBD> CasosClinicos { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new ContaTypeConfiguration());
            modelBuilder.Configurations.Add(new CasoClinicoTypeConfiguration());

            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }
    }
}