﻿using smed_csharp.Models.CasosClinicos;
using smed_csharp.Models.repositorio.ef.entidadesBD;
using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Web;

namespace smed_csharp.Models.Util.EF
{
    public class CasoClinicoTypeConfiguration : EntityTypeConfiguration<CasoClinicoBD>
    {
        public CasoClinicoTypeConfiguration()
        {
            // Mapeando a tabela 
            this.ToTable("CasoClinicoDB");

            // Configurando a chave primária 
            this.HasKey(c => c.descricao);

            // Mapeando colunas 
            //this.Property(c => c.descricao).HasColumnName("descricao");

            //this.Property(c => c.titulo).HasColumnName("titulo");



        }
    }
}
