using smed_csharp.Models.CasosClinicos;
using smed_csharp.Models.Contas;
using smed_csharp.Models.mensagem;

namespace smed_csharp.Models.Util
{
	public class FabricaRepositoriosBDR : FabricaRepositorioAbstrata
	{
        

        public IRepositorioContas criarRepositorioContas()
        { 
        	return new RepositorioContasBDR();
        }

        public IRepositorioCasosClinicos criarRepositorioCasosClinicos()
        { 
        	return new RepositorioCasosClinicosBDR();
        }

        public IRepositorioMensagem criarRepositorioMensagem()
        { 
        	return new RepositorioMensagemBDR();
        }


	}
}