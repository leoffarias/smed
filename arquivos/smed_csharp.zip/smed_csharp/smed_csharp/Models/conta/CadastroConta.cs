﻿using smed_csharp.Models.Util;
using System.Collections.Generic;

namespace smed_csharp.Models.Contas
{
    class CadastroConta
    {
        private IRepositorioContas repositorioContas;

        public CadastroConta(FabricaRepositorioAbstrata fabrica)
        {
            this.repositorioContas = fabrica.criarRepositorioContas();
        }

        public void add(Conta conta)
        {
            repositorioContas.add(conta);
        }

        public ICollection<Conta> getAll()
        {
            return repositorioContas.getAll();
        }
    }
}