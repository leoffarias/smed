﻿using System.Collections.Generic;

namespace smed_csharp.Models.Contas
{
    public interface IRepositorioContas
    {
        void add(Conta conta);

        ICollection<Conta> getAll();
    }
}
