﻿using System.Collections.Generic;
using smed_csharp.Models.repositorio.ef.entidadesBD;
using smed_csharp.Models.Util.EF;

namespace smed_csharp.Models.Contas
{
    public class RepositorioContasBDR : IRepositorioContas
    {

        public RepositorioContasBDR()
        {
        }

        public void add(Conta conta)
        {
            using (SmedContext context = new SmedContext())
            {
                string email = conta.email;

                if (conta.email == null) email = "";

                ContaBD t = new ContaBD(conta.id, conta.nome, email);

                foreach(var c in context.Contas)
                {
                    if (c.id == conta.id) return;
                }

                context.Contas.Add(t);
                context.SaveChanges();                
            }
        }

        //TODO: implementar
        public ICollection<Conta> getAll()
        {
            List<Conta> result = new List<Conta>();
            using(SmedContext context = new SmedContext())
            {
                foreach (ContaBD c in context.Contas)
                {
                    Conta temp = new Conta(c.id, c.nome, c.email);
                    result.Add(temp);
                }
                    
            }
            return result;
        }
        
        
    }
}