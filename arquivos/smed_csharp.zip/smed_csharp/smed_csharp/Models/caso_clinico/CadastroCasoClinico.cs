﻿using smed_csharp.Models.Contas;
using smed_csharp.Models.Util;
using System.Collections.Generic;

namespace smed_csharp.Models.CasosClinicos
{
    class CadastroCasoClinico
    {
        IRepositorioCasosClinicos repositorioCasosClinicos;

        public CadastroCasoClinico(FabricaRepositorioAbstrata fabrica)
        {
            this.repositorioCasosClinicos = fabrica.criarRepositorioCasosClinicos();
        }

        public void add(CasoClinico casoClinico)
        {
            repositorioCasosClinicos.add(casoClinico);
        }

        public ICollection<CasoClinico> listarCasosClinicos(Conta conta)
        {
            return repositorioCasosClinicos.listarCasosClinicos(conta);
        }
    }
}