﻿using smed_csharp.Models.Contas;
using System.Collections.Generic;

namespace smed_csharp.Models.CasosClinicos
{
    public interface IRepositorioCasosClinicos
    {

        void add(CasoClinico casoClinico);

        ICollection<CasoClinico> listarCasosClinicos(Conta conta);

    }
}