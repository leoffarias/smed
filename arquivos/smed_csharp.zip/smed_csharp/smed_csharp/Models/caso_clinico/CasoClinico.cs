﻿using smed_csharp.Models.Contas;
using smed_csharp.Models.mensagem;
using System;
using System.Collections.Generic;

namespace smed_csharp.Models.CasosClinicos
{

    public class CasoClinico
    {

        public string titulo { get; internal set; }

        public string descricao { get; internal set; }

        public ICollection<Mensagem> mensagens { get; internal set; }

        public ICollection<Conta> participantes { get; internal set; }

        public CasoClinico(String titulo, String descricao,
                ICollection<Conta> participantes)
        {

            this.titulo = titulo;
            this.descricao = descricao;
            this.participantes = participantes;
            this.mensagens = new List<Mensagem>();
        }

        public CasoClinico(string titulo, string descricao) {
            this.titulo = titulo;
            this.descricao = descricao;
            this.mensagens = new List<Mensagem>();
            this.participantes = new List<Conta>();               
        }

        public CasoClinico() {
        }
    }
    
}