﻿using smed_csharp.Models.Contas;
using smed_csharp.Models.repositorio.ef.entidadesBD;
using smed_csharp.Models.Util.EF;
using System.Collections.Generic;

namespace smed_csharp.Models.CasosClinicos
{
    public class RepositorioCasosClinicosBDR : IRepositorioCasosClinicos
    {
        public void add(CasoClinico casoClinico)
        {


            using (SmedContext context = new SmedContext())
            {
                CasoClinicoBD c = new CasoClinicoBD(casoClinico.titulo, casoClinico.descricao, casoClinico.participantes);
                context.CasosClinicos.Add(c);
                context.SaveChanges();
            }
        }

        public ICollection<CasoClinico> listarCasosClinicos(Conta conta)
        {
            List<CasoClinico> result = new List<CasoClinico>();


            using (SmedContext context = new SmedContext())
            {
                

                foreach(var caso in context.CasosClinicos)
                {
                    if(caso.participantes != null && conta != null) //TODO: analisar problema de concorrência
                    {
                        foreach (var usuario in caso.participantes.Split(';'))
                        {
                            if (conta.id == usuario)
                            {
                                CasoClinico temp = new CasoClinico(caso.titulo, caso.descricao);
                                temp.participantes.Add(conta);
                                result.Add(temp);
                                break;
                            }
                        }
                    }                   
                }
            }
            return result;
        }
    }
}