﻿using Facebook;
using System;

namespace smed_csharp.Models.Facebook
{
    public class ComunicacaoFacebook
        : ISubsistemaComunicacaoFacebook
    {
        FacebookClient fb;

        public ComunicacaoFacebook()
        {
            fb = new FacebookClient();
        }

        public Uri conectar(Uri RedirectUri)
        {
            return this.comporUrlLogin(RedirectUri);   
        }

        public dynamic autorizar(string code, Uri RedirectUri)
        {
            dynamic result = fb.Post(Config.OAUTH_ENDPOINT, new
            {
                client_id = Config.CLIENT_ID,
                client_secret = Config.CLIENT_SECRET,
                redirect_uri = RedirectUri.AbsoluteUri,
                code = code
            });

            var accessToken = result.access_token;
            fb.AccessToken = accessToken;

            dynamic me = fb.Get("me?fields=name,id,email");

            return me;
        }

        private Uri comporUrlLogin(Uri RedirectUri)
        {
            var loginUrl = fb.GetLoginUrl(new
            {
                client_id = Config.CLIENT_ID,
                client_secret = Config.CLIENT_SECRET,
                redirect_uri = RedirectUri.AbsoluteUri,
                response_type = "code",
                scope = "email"
            });

            return loginUrl;
        }
    }
}