﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace smed_csharp.Models.Facebook
{
    interface ISubsistemaComunicacaoFacebook
    {
        Uri conectar(Uri RedirectUri);

        dynamic autorizar(string code, Uri RedirectUri);
    }
}
