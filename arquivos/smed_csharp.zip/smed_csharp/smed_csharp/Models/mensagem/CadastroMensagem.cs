﻿using smed_csharp.Models.mensagem;
using smed_csharp.Models.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace smed_csharp.Models.mensagem
{
    public class CadastroMensagem
    {
        IRepositorioMensagem repositorioMensagem;

        public CadastroMensagem(FabricaRepositorioAbstrata fabrica)
        {
            this.repositorioMensagem = fabrica.criarRepositorioMensagem();
        }

        public void add(Mensagem mensagem)
        {
            this.repositorioMensagem.add(mensagem);
        }
    }

}