﻿using smed_csharp.Models.mensagem;
using System;

namespace smed_csharp.Models.mensagem
{
    public class RepositorioMensagemBDR : IRepositorioMensagem
    {
        public void add(Mensagem mensagem)
        {
            throw new NotImplementedException();
        }
    }
}