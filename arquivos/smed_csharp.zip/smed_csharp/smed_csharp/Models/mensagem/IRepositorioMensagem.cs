﻿using smed_csharp.Models.mensagem;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace smed_csharp.Models.mensagem
{
    public interface IRepositorioMensagem
    {
        void add(Mensagem mensagem);
    }

}