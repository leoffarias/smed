﻿using smed_csharp.Models.Contas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace smed_csharp.Models.mensagem
{

    public class Mensagem
    {
        public string conteudo { get; internal set; }

        public DateTime data { get; internal set; }

        public Conta remetente { get; internal set; }

        public Mensagem(String conteudo, DateTime data, Conta remetente)
        {
            this.conteudo= conteudo;
            this.data = data;
            this.remetente = remetente;
        }
    }
}