﻿using smed_csharp.Models.CasosClinicos;
using smed_csharp.Models.Contas;
using smed_csharp.Models.Controladores;
using smed_csharp.Models.mensagem;
using smed_csharp.Models.Util;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace smed_csharp.Models
{
    public sealed class Fachada
    {
        private static Fachada instance;

        private ControladorChat controladorChat;

        private ControladorCasoClinico controladorCasoClinico;

        private ControladorConta controladorConta;

        private FabricaRepositorioAbstrata fabrica;

        private Fachada()
        {
            string banco = System.Configuration.ConfigurationManager.AppSettings["database"];

            if (banco == "relacional")
                this.fabrica = new FabricaRepositoriosBDR();
            else
                throw new Exception("o tipo de banco de dados escolhido não é valido");

            controladorChat = new ControladorChat(this.fabrica);
            controladorCasoClinico = new ControladorCasoClinico(this.fabrica);
            controladorConta = new ControladorConta(this.fabrica);
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public static Fachada getInstance()
        {
            if (instance == null)
            {
                instance = new Fachada();
            }
            return instance;
        }

        public ICollection<Conta> listarUsuarios() { return controladorConta.listarContas(); }

        public void criarCasoClinico(CasoClinico casoClinico) { controladorCasoClinico.criarCasoClinico(casoClinico); }

        public Uri conectarFacebook(Uri redirectUri) { return controladorConta.conectarFacebook(redirectUri); }

        public dynamic autorizarFacebook(Uri redirectUri, String tokenCliente) { return controladorConta.autorizarFacebook(redirectUri, tokenCliente); } 

        public void criarConta(Conta conta) { controladorConta.criarConta(conta); }

        public ICollection<CasoClinico> listarCasosClinicos(Conta conta) { return controladorCasoClinico.listarCasosClinicos(conta); }

        public void criarMensagem(Mensagem mensagem, CasoClinico casoClinico) { controladorChat.criarMensagem(mensagem, casoClinico); }

    }
}