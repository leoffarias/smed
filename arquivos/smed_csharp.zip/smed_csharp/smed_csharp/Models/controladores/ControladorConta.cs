﻿using smed_csharp.Models.Contas;
using smed_csharp.Models.Facebook;
using smed_csharp.Models.Util;
using System;
using System.Collections.Generic;

namespace smed_csharp.Models.Controladores
{
    class ControladorConta
    {
        private CadastroConta cadastroContas;

        private ISubsistemaComunicacaoFacebook facebook;

        public ControladorConta(FabricaRepositorioAbstrata fabrica)
        {
            this.cadastroContas = new CadastroConta(fabrica);
            facebook = new ComunicacaoFacebook();
        }

        public void criarConta(Conta conta)
        {
            cadastroContas.add(conta);
        }

        public ICollection<Conta> listarContas()
        {
            return cadastroContas.getAll();
        }

        public Uri conectarFacebook(Uri redirectUri) {
            return facebook.conectar(redirectUri);
        }

        public Conta autorizarFacebook(Uri redirectUri, String tokenCliente) {

            dynamic me = facebook.autorizar(tokenCliente, redirectUri);

            string email = me.email;

            if (email == null)
                email = "";

            Conta conta = new Conta(me.id, me.name, email);

            this.criarConta(conta);

            return conta;
        }

    }
}