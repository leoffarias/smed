﻿using smed_csharp.Models.CasosClinicos;
using smed_csharp.Models.Contas;
using smed_csharp.Models.Util;
using System.Collections.Generic;

namespace smed_csharp.Models.Controladores
{
    class ControladorCasoClinico
    {
        private CadastroCasoClinico cadastroCasosClinicos;

        public ControladorCasoClinico(FabricaRepositorioAbstrata fabrica)
        {
            this.cadastroCasosClinicos = new CadastroCasoClinico(fabrica);
        }

        public void criarCasoClinico(CasoClinico casoClinico)
        {
            cadastroCasosClinicos.add(casoClinico);
        }

        public ICollection<CasoClinico> listarCasosClinicos(Conta conta)
        {
            return this.cadastroCasosClinicos.listarCasosClinicos(conta); ;
        }
    }
}