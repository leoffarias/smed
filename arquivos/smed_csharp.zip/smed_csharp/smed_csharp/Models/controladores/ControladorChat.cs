﻿using smed_csharp.Models.CasosClinicos;
using smed_csharp.Models.mensagem;
using smed_csharp.Models.Util;

namespace smed_csharp.Models.Controladores
{
    class ControladorChat
    {
        private CadastroMensagem cadastroMensagem;

        public ControladorChat(FabricaRepositorioAbstrata fabrica)
        {
            this.cadastroMensagem = new CadastroMensagem(fabrica);
        }

        public void criarMensagem(Mensagem mensagem, CasoClinico casoClinico)
        {
            this.cadastroMensagem.add(mensagem);
            casoClinico.mensagens.Add(mensagem);
        }
    }
}