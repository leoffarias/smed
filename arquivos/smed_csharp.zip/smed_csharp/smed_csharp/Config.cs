﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace smed_csharp
{
    public static class Config
    {
        public static readonly string CLIENT_ID = "1511266992527723";
        public static readonly string CLIENT_SECRET = "4767afe57b858381ab87fe04212a6d88";
        public static readonly string OAUTH_ENDPOINT = "oauth/access_token";
    }
}